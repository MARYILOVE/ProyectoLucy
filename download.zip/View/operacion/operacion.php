<div class="container">
  <h1 class="page-header titulo">Operaciones </h1>
    <a class="btn btn-primary" href="?c=operacion&a=Nuevo">Nuevo Operacion</a>
  
  <table class="table">
    <tr>
      <td>AQUI VA CONSULTA</td>
    </tr>
  </table>
</div>