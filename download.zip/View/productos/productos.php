<div class="container">
  <h1 class="page-header titulo">Productos </h1>
    <a class="btn btn-primary" href="?c=productos&a=Nuevo">Nuevos Productos</a>
    <a class="btn btn-primary" href="?c=materiales&a=NuevoMaterial">Nuevos material</a>
  
  