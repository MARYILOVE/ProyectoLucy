<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">LUCY</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">INICIO</a></li>
      <li><a href="?c=usuarios">USUARIOS</a></li>
      <li><a href="?c=operacion">OPERACION</a></li>
      <li><a href="?c=productos">PRODUCTOS</a></li>
			 
    </ul>
		<ul class="nav navbar-nav navbar-right">
       <li><a href="?c=login&a=cerrarSesion"><span class="glyphicon glyphicon-log-out"></span> CERRAR SESION</a></li>
    </ul>
  </div>
</nav>		