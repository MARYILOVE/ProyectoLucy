<div class="container">
  <h1 class="page-header titulo">Usuarios </h1>
    <a class="btn btn-primary" href="?c=usuarios&a=nuevo">Registrar usuario</a>
    <a class="btn btn-primary" href="?c=materiales&a=NuevoMaterial">consultar usuario</a>
</div> 